# Held-Out Casting Test Set Attribution

- **Dataset**: [Real-Life Industrial Dataset of Casting Product](https://www.kaggle.com/datasets/ravirajsinh45/real-life-industrial-dataset-of-casting-product)
- **Creator / Dataset Provider**: Raviraj Joshi
- **License**: [CC BY-NC-ND 4.0 (Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International)](https://creativecommons.org/licenses/by-nc-nd/4.0/)
- **Scope Included**: All 1,041 strictly held-out `test` split images from `outputs/data/split_manifest.csv` (602 `def_front`, 439 `ok_front`), preserving exact original image bytes verified via SHA-256.
